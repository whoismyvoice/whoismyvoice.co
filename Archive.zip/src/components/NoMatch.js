import React from 'react';

const NoMatch = () => {
  return <div className="error">
    Page does not exist
  </div>;
};

export default NoMatch;
