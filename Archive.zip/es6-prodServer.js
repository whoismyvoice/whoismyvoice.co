// es6-prodServer.js transpiles files using babel/register
require('babel-core/register');
require('./prodServer.js');
