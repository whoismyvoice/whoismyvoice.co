// es6-devServer.js transpiles files using babel/register
require('babel-core/register');
require('./devServer.js');
