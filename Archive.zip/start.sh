#!/bin/bash
npm install
npm run build:start
